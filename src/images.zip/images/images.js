const Images = {
  logoLight: require('./logo/logo_light.png'),
  logoDark: require('./logo/logo_dark.png'),
};

export default Images;
